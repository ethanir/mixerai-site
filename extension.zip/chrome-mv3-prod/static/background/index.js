var e,t;"function"==typeof(e=globalThis.define)&&(t=e,e=null),function(t,r,o,a,i){var s="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:"undefined"!=typeof window?window:"undefined"!=typeof global?global:{},n="function"==typeof s[a]&&s[a],c=n.cache||{},l="undefined"!=typeof module&&"function"==typeof module.require&&module.require.bind(module);function h(e,r){if(!c[e]){if(!t[e]){var o="function"==typeof s[a]&&s[a];if(!r&&o)return o(e,!0);if(n)return n(e,!0);if(l&&"string"==typeof e)return l(e);var i=Error("Cannot find module '"+e+"'");throw i.code="MODULE_NOT_FOUND",i}u.resolve=function(r){var o=t[e][1][r];return null!=o?o:r},u.cache={};var d=c[e]=new h.Module(e);t[e][0].call(d.exports,u,d,d.exports,this)}return c[e].exports;function u(e){var t=u.resolve(e);return!1===t?{}:h(t)}}h.isParcelRequire=!0,h.Module=function(e){this.id=e,this.bundle=h,this.exports={}},h.modules=t,h.cache=c,h.parent=n,h.register=function(e,r){t[e]=[function(e,t){t.exports=r},{}]},Object.defineProperty(h,"root",{get:function(){return s[a]}}),s[a]=h;for(var d=0;d<r.length;d++)h(r[d]);if(o){var u=h(o);"object"==typeof exports&&"undefined"!=typeof module?module.exports=u:"function"==typeof e&&e.amd?e(function(){return u}):i&&(this[i]=u)}}({kgW6q:[function(e,t,r){e("../../../background")},{"../../../background":"8VaxY"}],"8VaxY":[function(e,t,r){var o=e("~lib/config"),a=e("~lib/orchestrator");chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:!0}).catch(e=>console.error("[SuperAI] sidePanel setup failed",e));let i=new Map;function s(){chrome.runtime.sendMessage({type:"STATUS_BROADCAST",statuses:Array.from(i.values())}).catch(()=>{})}async function n(e){for(let t of e){let e=o.SERVICE_URLS[t],r=await chrome.tabs.query({url:`${e}/*`});if(0===r.length){i.delete(t);continue}let a=r[0].id;void 0!==a&&chrome.tabs.sendMessage(a,{type:"CHECK_AUTH"}).catch(()=>{})}s()}chrome.runtime.onMessage.addListener((e,t,r)=>{if("AUTH_STATE_UPDATE"===e.type){i.set(e.payload.service,e.payload),s();return}if("GET_ALL_STATUSES"===e.type)return r(Array.from(i.values())),!0;if("REFRESH_ALL"===e.type){n(e.services);return}if("OPEN_ALL"===e.type){h(e.services);return}if("OPEN_SERVICE"===e.type){d(e.service);return}});let c=["chatgpt","claude","gemini","perplexity"];async function l(){let e=!1;for(let t of c){let r=o.SERVICE_URLS[t],a=await chrome.tabs.query({url:`${r}/*`});0===a.length&&i.has(t)&&(i.delete(t),e=!0)}e&&s()}async function h(e){for(let t of e){let e=o.SERVICE_URLS[t],r=await chrome.tabs.query({url:`${e}/*`});0===r.length&&await chrome.tabs.create({url:e,active:!1})}}async function d(e){let t=o.SERVICE_URLS[e],r=await chrome.tabs.query({url:`${t}/*`});if(r.length>0){let e=r[0];void 0!==e.id&&await chrome.tabs.update(e.id,{active:!0}),void 0!==e.windowId&&await chrome.windows.update(e.windowId,{focused:!0})}else await chrome.tabs.create({url:t,active:!0})}chrome.tabs.onRemoved.addListener(()=>{l()}),chrome.tabs.onUpdated.addListener((e,t)=>{t.url&&l()}),chrome.runtime.onConnect.addListener(e=>{if("task-execution"!==e.name)return;let t=!1;e.onDisconnect.addListener(()=>{t=!0}),e.onMessage.addListener(async r=>{if("EXECUTE_TASK"!==r.type)return;let o=r=>{if(!t)try{e.postMessage(r)}catch{}},i="mixerai-task-keepalive";chrome.runtime.getPlatformInfo().catch(()=>{}),chrome.alarms.create(i,{periodInMinutes:.5});let s=setInterval(()=>{chrome.runtime.getPlatformInfo().catch(()=>{})},15e3);console.log(`[MixerAI/sw] task started \u2014 alarms + setInterval keepalive armed`);try{await (0,a.executeTask)(r.prompt,r.plan,o),console.log("[MixerAI/sw] task completed normally")}catch(e){console.log(`[MixerAI/sw] task threw: ${e instanceof Error?e.message:String(e)}`),o({type:"TASK_ERROR",error:e instanceof Error?e.message:String(e)})}finally{clearInterval(s),chrome.alarms.clear(i).catch(()=>{})}})}),chrome.alarms.onAlarm.addListener(e=>{e.name})},{"~lib/config":"kdNLa","~lib/orchestrator":"bAklx"}],kdNLa:[function(e,t,r){var o=e("@parcel/transformer-js/src/esmodule-helpers.js");o.defineInteropFlag(r),o.export(r,"PLANNER_URL",()=>a),o.export(r,"SERVICE_URLS",()=>i),o.export(r,"PROMPT_TIMEOUT_MS",()=>s);let a="https://mixerai-production.up.railway.app/plan",i={chatgpt:"https://chatgpt.com",claude:"https://claude.ai",gemini:"https://gemini.google.com",deepseek:"https://chat.deepseek.com",perplexity:"https://www.perplexity.ai"},s=54e4},{"@parcel/transformer-js/src/esmodule-helpers.js":"f6DG4"}],f6DG4:[function(e,t,r){r.interopDefault=function(e){return e&&e.__esModule?e:{default:e}},r.defineInteropFlag=function(e){Object.defineProperty(e,"__esModule",{value:!0})},r.exportAll=function(e,t){return Object.keys(e).forEach(function(r){"default"===r||"__esModule"===r||t.hasOwnProperty(r)||Object.defineProperty(t,r,{enumerable:!0,get:function(){return e[r]}})}),t},r.export=function(e,t,r){Object.defineProperty(e,t,{enumerable:!0,get:r})}},{}],bAklx:[function(e,t,r){var o=e("@parcel/transformer-js/src/esmodule-helpers.js");o.defineInteropFlag(r),o.export(r,"executeTask",()=>i),o.export(r,"buildProposerPrompt",()=>p),o.export(r,"buildAggregatorPrompt",()=>m),o.export(r,"buildCriticPrompt",()=>g),o.export(r,"buildRevisionPrompt",()=>y);var a=e("./config");async function i(e,t,r){let o=[...t.proposers.map(e=>e.service),t.aggregator.service];t.critic&&o.push(t.critic.service),await l(Array.from(new Set(o)));let a=p(e,t),i=await Promise.allSettled(t.proposers.map(async e=>{r({type:"PROPOSER_STARTED",service:e.service});let t=Date.now();try{let o=await c(e.service,a),i=Date.now()-t;if(!o||0===o.trim().length){let t=`${e.service}: response captured was empty. The page selectors may need updating.`;throw r({type:"PROPOSER_FAILED",service:e.service,error:t}),Error(t)}return r({type:"PROPOSER_DONE",service:e.service,text:o,durationMs:i}),{service:e.service,text:o,durationMs:i}}catch(o){let t=o instanceof Error?o.message:String(o);throw r({type:"PROPOSER_FAILED",service:e.service,error:t}),o}})),s=i.filter(e=>"fulfilled"===e.status).map(e=>e.value);if(0===s.length){let e=i.filter(e=>"rejected"===e.status).map(e=>e.reason instanceof Error?e.reason.message:String(e.reason)).join("; ");throw Error(`All proposers failed: ${e}`)}if("simple"===t.strategy){let e=s[0].text;return r({type:"AGGREGATOR_DONE",text:e,durationMs:0}),r({type:"TASK_COMPLETE",finalText:e}),e}r({type:"AGGREGATOR_STARTED",service:t.aggregator.service});let n=m(e,s,t,"moa_critic"===t.strategy),h=Date.now(),d=await c(t.aggregator.service,n);if(r({type:"AGGREGATOR_DONE",text:d,durationMs:Date.now()-h}),"moa"===t.strategy||!t.critic)return r({type:"TASK_COMPLETE",finalText:d}),d;r({type:"CRITIC_STARTED",service:t.critic.service});let u=g(e,d,t),f=Date.now(),w=await c(t.critic.service,u);r({type:"CRITIC_DONE",text:w,durationMs:Date.now()-f}),r({type:"REVISION_STARTED",service:t.aggregator.service});let T=y(e,d,w,t),E=Date.now(),I=await c(t.aggregator.service,T);return r({type:"REVISION_DONE",text:I,durationMs:Date.now()-E}),r({type:"TASK_COMPLETE",finalText:I}),I}let s=1;async function n(e,t,r){try{let o=await chrome.tabs.sendMessage(e,{type:"GET_CACHED_RESULT",requestId:t});if(!o||!o.found)return console.log(`[MixerAI/orch] recovery: ${r} GET_CACHED_RESULT requestId=${t} \u2192 no cached result (${o?.reason??"no-response"})`),null;if(o.error)return console.log(`[MixerAI/orch] recovery: ${r} GET_CACHED_RESULT requestId=${t} \u2192 cached ERROR`),{ok:!1,error:o.error};return console.log(`[MixerAI/orch] recovery: ${r} GET_CACHED_RESULT requestId=${t} \u2192 cached OK textLen=${(o.text??"").length}`),{ok:!0,text:o.text??""}}catch(e){return console.log(`[MixerAI/orch] recovery: ${r} GET_CACHED_RESULT requestId=${t} \u2192 threw ${e instanceof Error?e.message:String(e)}`),null}}async function c(e,t){let r=a.SERVICE_URLS[e],o=await chrome.tabs.query({url:`${r}/*`});if(0===o.length)throw Error(`No tab open for ${e}`);let i=o[0].id;if(void 0===i)throw Error(`Could not get tab id for ${e}`);let c=s++,l=Date.now();return console.log(`[MixerAI/orch] -> sendPromptToService(${e}) tab=${i} requestId=${c}`),new Promise((r,o)=>{let s,h=!1,d=null,u=t=>{if(!h){h=!0,null!==d&&clearTimeout(d),console.log(`[MixerAI/orch] <- ${e} RESULT.ok requestId=${c} textLen=${t.length} elapsed=${Math.round((Date.now()-l)/1e3)}s`);try{s.disconnect()}catch{}r(t)}},f=t=>{if(!h){h=!0,null!==d&&clearTimeout(d),console.log(`[MixerAI/orch] <- ${e} ERROR requestId=${c} msg="${t.message}" elapsed=${Math.round((Date.now()-l)/1e3)}s`);try{s.disconnect()}catch{}o(t)}},p=async t=>{if(h)return;console.log(`[MixerAI/orch] ${e} port died without RESULT (${t}) \u2014 attempting cache recovery requestId=${c}`);let r=await n(i,c,e);if(!h){if(null!==r){"text"in r?u(r.text):f(Error(`${e}: ${r.error}`));return}f(Error(`${e}: port disconnected (${t})`))}};try{s=chrome.tabs.connect(i,{name:"mixerai-send-prompt"})}catch(t){return o(Error(`${e}: could not connect to content script (page may need refresh)`))}s.onMessage.addListener(t=>{if(t?.type==="RESULT"){if("number"==typeof t.requestId&&t.requestId!==c){console.log(`[MixerAI/orch] ${e} ignoring stale RESULT (got requestId=${t.requestId}, expected ${c})`);return}t.ok?u(t.text??""):f(Error(`${e}: ${t.error??"unknown error"}`))}}),s.onDisconnect.addListener(()=>{let e=chrome.runtime.lastError?.message;p(e??"port disconnected before response")});try{s.postMessage({type:"SEND_PROMPT",prompt:t,requestId:c})}catch(t){f(Error(`${e}: failed to post prompt to content script (${t instanceof Error?t.message:String(t)})`))}d=setTimeout(async()=>{if(h)return;let t=await n(i,c,e);if(!h){if(null!==t&&"text"in t){console.log(`[MixerAI/orch] ${e} hard-timeout recovery succeeded requestId=${c}`),u(t.text);return}f(Error(`${e}: timed out after ${a.PROMPT_TIMEOUT_MS}ms`))}},a.PROMPT_TIMEOUT_MS)})}async function l(e){for(let t of e){let e=a.SERVICE_URLS[t],r=await chrome.tabs.query({url:`${e}/*`});if(0===r.length){let t=await chrome.tabs.create({url:e,active:!1});await h(t.id)}}}async function h(e,t=15e3){let r=Date.now();for(;Date.now()-r<t;){try{let t=await chrome.tabs.sendMessage(e,{type:"CHECK_AUTH"});if(t)return}catch{}await new Promise(e=>setTimeout(e,500))}}function d(e){let t=(e||"").toLowerCase();return/code|coding|debug|refactor|algorithm|programm|function|script/.test(t)?"code":/math|proof|prove|theorem|equation/.test(t)?"math":/writ|creative|story|essay|poem|article|blog|content|copy/.test(t)?"writing":/research|current|news|recent|fact-check|factual|investigat|summari|search/.test(t)?"research":/explan|tutorial|definition|teach|learn|how does|understand/.test(t)?"explanation":/compar|recomm|evaluat|choos|pick|select|versus|vs|review|analy|breakdown/.test(t)?"comparison":/brainstorm|idea|ideation|generat/.test(t)?"brainstorm":"default"}let u={code:`THIS IS A CODING TASK. Non-negotiables:

1. Write WORKING code, not pseudocode (unless explicitly asked).
2. Before finalizing, TRACE your code on a small concrete input mentally. Catch off-by-one errors, null/empty handling, infinite loops.
3. Then trace ONE edge case: empty input, single element, max size, negative numbers, duplicates. Whichever applies.
4. State time and space complexity at the end.
5. State assumptions about the input or environment if any matter.
6. If the user asked for tests, write them. If not, include at least one example call showing the function in use.
7. Use idiomatic style for the language. Match modern conventions.
8. Comments where they add value, not where they restate code.

Wrong code reaches the user only if you ship it. Don't ship wrong code.`,math:`THIS IS A MATH OR PROOF TASK. Non-negotiables:

1. Prove every step. Skipped "obvious" transitions are where errors hide.
2. Verify your final answer with a CONCRETE numeric example (n=3, n=4, k=1, etc.). Show the verification.
3. Check index boundaries \u2014 off-by-one errors are the #1 cause of wrong proofs.
4. If you used induction, verify the base case explicitly. Don't say "base case trivial" \u2014 show it.
5. Define every variable before it appears in an equation. State assumptions before using them.
6. If you invoked a named theorem, name it.
7. The final claim must be UNAMBIGUOUS. A reader shouldn't have to guess what you proved.

A wrong proof that looks right is worse than a missing proof. Self-check before shipping.`,writing:`THIS IS A WRITING TASK. Non-negotiables:

1. Voice matters. Match the audience, register, and intent of the request.
2. Specific concrete details ALWAYS beat general ones. Real examples beat abstract claims.
3. Cut every word that isn't earning its place. Verbosity is laziness in disguise.
4. NO corporate hedging ("It's important to note that\u2026"). NO filler openers ("In today's fast-paced world\u2026"). NO empty transitions ("Furthermore," "Moreover,").
5. Read your draft back mentally before shipping. Fix anything that sounds like a robot wrote it.
6. Lead with the strongest line. End with weight, not whimper.
7. Match the requested length and format exactly. If they said 300 words, count.

Generic safe writing is the failure mode. Be specific and committed.`,research:`THIS IS A RESEARCH OR FACT-FINDING TASK. Non-negotiables:

1. USE WEB SEARCH. This is not optional. Your training data is stale on anything time-sensitive.
2. Cite the source for every non-obvious claim (number, date, name, quote).
3. Distinguish confirmed facts from reported claims from speculation. Use the language precisely.
4. If sources disagree, say so explicitly. Do NOT average them. Pick the most credible and say why.
5. Prefer recent sources (last 6 months) for time-sensitive topics.
6. If you cannot find a credible source for something, say so. Do not invent.
7. Hallucinated facts are unacceptable. Verification is the entire point of this task.

If you didn't search the web at least once, you didn't do this task.`,explanation:`THIS IS AN EXPLANATION OR TUTORIAL TASK. Non-negotiables:

1. Match the user's apparent expertise level. Don't condescend; don't lose them.
2. Start from a CONCRETE example. Theory follows. Not the other way around.
3. Define jargon the first time you use it. Then assume it's understood.
4. Include at least one worked example: "Here's how this plays out in practice."
5. Where relevant, name the common wrong intuition AND why it's wrong. Misconceptions are the most valuable thing to address.
6. End with the single most important takeaway in one line.
7. Length matches complexity, not enthusiasm. Don't pad.

A confused reader is a failed explanation, regardless of how technically correct you were.`,comparison:`THIS IS A COMPARISON OR RECOMMENDATION TASK. Non-negotiables:

1. Define the criteria you're comparing on FIRST. Don't list features randomly.
2. For each criterion, state which option wins and WHY in one line.
3. Identify the genuine tradeoffs \u2014 what each option SACRIFICES to be good at what it's good at.
4. If the user asked for a recommendation, COMMIT to one. Don't hedge with "depends on your needs" unless you enumerate which needs lead to which choice.
5. Identify the "wrong answer" \u2014 the option that would be a mistake for most users in this context.
6. Note anything the user didn't ask about that matters anyway (pricing, vendor lock-in, ecosystem, longevity).
7. End with a one-sentence verdict.

Wishy-washy comparisons are useless. Pick a side and defend it.`,brainstorm:`THIS IS A BRAINSTORM OR IDEATION TASK. Non-negotiables:

1. Quantity AND quality. If they asked for N ideas, give N DISTINCT ones \u2014 not M good ones and (N-M) fillers.
2. Range matters. Cover the safe / conventional ideas AND the weirder ones at the edges.
3. Each idea: name + one-line description + one-line "why it could work" (specific mechanism, not vague optimism).
4. Drop duplicates and obvious ones. Don't pad to hit a count.
5. The non-obvious ideas are where the value is. Surface them deliberately.
6. Avoid generic startup-speak. "AI-powered platform for X" is not an idea \u2014 it's a sentence template.

A list of safe ideas is worse than fewer bold ones.`,default:`THIS TASK DOESN'T FIT A STANDARD CATEGORY \u2014 coding, math, research, etc. That's fine. Many of the most important tasks are open-ended human ones: advice, decisions, planning, opinions, conversation, creative play, emotional topics, life questions, mixed-domain work.

For tasks like these, the failure modes are different. Watch out for:

1. IDENTIFY WHAT KIND OF HELP THE USER ACTUALLY WANTS. Read carefully:
   - Are they asking for a DECISION? Give one, with reasoning. Don't list pros and cons forever.
   - Are they asking to THINK THROUGH something? Lay out the considerations clearly, then suggest a direction.
   - Are they asking for EMPATHY or support? Lead with that. Don't jump to advice.
   - Are they asking for CREATIVE help? Be playful, be specific, bring real voice \u2014 not corporate-AI-helpful.
   - Are they asking for PRACTICAL steps? Give actual concrete steps, not abstract principles.
   - Are they asking your OPINION? Give it, explicitly.

2. MATCH THE REGISTER the user used. Casual question \u2192 casual answer. Heavy or vulnerable question \u2192 take it seriously, slow down, don't be flippant.

3. AVOID the failure modes that make AI answers feel hollow:
   - Bullet-point cascades when prose would serve better.
   - Restating the question before answering it ("Great question! You're asking\u2026").
   - Generic principles when the user wanted specifics.
   - Over-cautious hedging when the user wanted a real opinion.
   - Refusing to commit when the user explicitly asked for your view.
   - "It depends" without saying ON WHAT it depends.

4. If the task is genuinely open-ended (e.g., "what should I do with my life"), don't pretend it has one right answer. Help the user think. Give your honest take when asked. Respect that they own the decision.

5. If the task involves MULTIPLE kinds of work (e.g., "research this then write a poem about it"), handle each part with the care it deserves. Don't shortchange one half.

The world is bigger than the tasks any checklist can cover. Use judgment. Be specific. Don't be generic.`},f={code:`Since this is a coding task, ALSO do this before shipping:
- Mentally COMPILE the final code. Step through one input. Check for syntax errors, off-by-one bugs, null handling.
- Verify the stated complexity matches the actual code.
- If the drafts disagreed on approach, pick the one that handles edge cases better, not the one that's shortest.`,math:`Since this is a math/proof task, ALSO do this before shipping:
- VERIFY the final answer with a concrete numeric example (n=3, n=4, etc.).
- Check the base case explicitly if induction is used.
- Check every index boundary. Off-by-one is the most common error class here.
- If drafts disagreed on a numerical answer, recompute from scratch.`,writing:`Since this is a writing task, ALSO do this before shipping:
- Cut every word that isn't earning its place. Aggregated drafts tend to bloat.
- Read your final version mentally. Fix anything that sounds AI-generated.
- Pick ONE voice and hold it throughout. Different drafts will have used different registers; harmonize.`,research:`Since this is a research task, ALSO do this before shipping:
- Use web search to VERIFY any specific claim (date, number, name, quote) that any draft made.
- If drafts disagreed on a fact, look it up. Do not average.
- Cite sources for non-obvious claims in the final answer.`,explanation:`Since this is an explanation task, ALSO do this before shipping:
- Lead with a concrete example, not abstract theory.
- Make sure jargon is defined on first use.
- End with the one-line takeaway.`,comparison:`Since this is a comparison/recommendation task, ALSO do this before shipping:
- COMMIT to a verdict. Don't hedge.
- Make the tradeoffs explicit \u2014 what each option gives up.`,brainstorm:`Since this is a brainstorm, ALSO do this before shipping:
- De-duplicate ideas that drafts shared. Don't count the same idea twice with different words.
- If counts were requested (e.g. "10 ideas"), hit the count EXACTLY with distinct ideas.`,default:`Before shipping, regardless of task type:
- RE-READ the user's original task. Verify your final answer actually addresses what they asked, not what's adjacent to it.
- MATCH THE LANGUAGE the user wrote in. Don't translate to English unless asked.
- MATCH THE REGISTER. Casual \u2192 casual. Emotional \u2192 human, not corporate. Technical \u2192 precise.
- CUT every line that's generic or filler. Aggregated drafts bloat by default.
- COMMIT where commitment was asked for. Don't dodge the actual question with "it depends" unless you specify on what.
- If drafts disagreed on something subjective (opinion, advice, recommendation), don't average. Pick what seems right and OWN it.`};function p(e,t){let r=u[d(t.task_type)];return`THIS IS NOT A CASUAL QUESTION. Treat this as a high-stakes task.

WHY: Other AIs are drafting the same task right now, in parallel, independently from you. The final answer the user sees will be SYNTHESIZED from your draft and theirs. Your job is to bring YOUR strongest, most committed take \u2014 not to anticipate consensus, not to play it safe, not to hedge.

UNIVERSAL RULES \u2014 apply to every task, no matter what:

1. READ THE TASK TWICE before answering. Don't skim. The first read finds what's asked; the second finds what's IMPLIED but not stated (the constraints, context, the real question behind the question).

2. IDENTIFY THE USER'S ACTUAL GOAL \u2014 what would a successful answer DO for them, not just say? An answer that says correct words but misses the real goal has failed.

3. MATCH THE USER'S LANGUAGE. If the task is written in Spanish, answer in Spanish. French, French. Mandarin, Mandarin. Same script, same register. Don't translate to English unless the task is asking for a translation.

4. MATCH THE USER'S REGISTER. Casual question \u2192 casual answer. Technical user \u2192 precise answer. Emotional or heavy question \u2192 take it seriously; slow down.

5. SPEED IS IRRELEVANT. Correctness is everything. Half-effort fails. There is no partial credit. There is no "good enough."

6. USE WEB SEARCH whenever ANY part is uncertain or time-sensitive. Your training data is stale on anything recent \u2014 prices, news, releases, current officeholders, sports results, anything dated.

7. BE SPECIFIC. Generic answers are worse than no answer. Concrete examples beat abstract claims every time.

8. COMMIT TO POSITIONS. Hedging is laziness. If you genuinely cannot decide between options, say so explicitly with reasoning \u2014 don't bury indecision in soft language ("it depends on your needs" without saying ON WHAT it depends).

9. IF A STEP FEELS OBVIOUS, write it anyway. Obvious steps hide errors.

10. VERIFY BEFORE YOU SHIP. Read your own draft once. Find what's wrong, fix it.

11. IF SOMETHING IS IMPOSSIBLE, AMBIGUOUS, OR UNKNOWN, say so. Don't fake confidence. Don't hallucinate to look helpful. Naming a gap is more useful than filling it with fiction.

12. LENGTH MATCHES WHAT'S ACTUALLY NEEDED. Don't pad. Don't truncate. Match the apparent scope of the request.

${r}

EXPECTED OUTPUT SHAPE: ${t.output_format}

Now the task below. Read it carefully. Do not skim. Answer it FULLY.

---

${e}`}function m(e,t,r,o=!1){let a=f[d(r.task_type)],i=a?`
${a}
`:"",s=t.map((e,t)=>`--- Draft ${t+1} (from ${e.service}) ---
${e.text.trim()}`).join("\n\n"),n=o?`

NOTE: A separate model (different from any of the drafters above) will review your output as a quality-check pass before it reaches the user. Write a sharp, committed draft \u2014 do NOT hedge to please the reviewer. The reviewer's job is to catch real errors, not to enforce blandness. Hedging now just creates more work for them and for you.`:"";return`THIS IS A SYNTHESIS TASK. You are the final author. The user will see only your output.

The user asked:

"""
${e}
"""

Task classification: ${r.task_type} (${r.difficulty} difficulty)
Required output format: ${r.output_format}

${t.length} AI models independently attempted this task. Their drafts are below. Read them carefully \u2014 but you are NOT picking one. You are RE-DERIVING the best answer using them as evidence.

${s}

---

PART 1 \u2014 AUDIT (internal, NOT shown in your output):

  a) For each draft, identify the strongest unique contribution it makes \u2014 a fact, a step, a perspective, a piece of reasoning the others missed.

  b) List EVERY point where the drafts DISAGREE \u2014 on a fact, a number, a logical step, a recommendation, a tradeoff. For each disagreement, work out which side is correct using first-principles reasoning.

     DO NOT AVERAGE DISAGREEMENTS.
     DO NOT SPLIT THE DIFFERENCE.
     DO NOT WRITE "some say X, others say Y."
     Pick the right answer and commit. If you're genuinely unsure, that's a signal you need to think harder, not present both sides.

  c) Identify any claim that ALL drafts make but might still be wrong. The collaborativeness property of MoA means models can all be confidently wrong together. Question shared claims.

  d) Identify anything the user actually needs that NONE of the drafts addressed. Plan to add it.

  e) Note any draft that is clearly weaker overall \u2014 discount it. Mixing perspectives helps; a confidently-wrong draft pulling synthesis off course does NOT help.
${i}
PART 2 \u2014 WRITE THE FINAL ANSWER (this IS what the user sees):

Re-derive the answer from scratch using your audit. Use the drafts as evidence and inspiration \u2014 NOT as base text to remix. The result must read as a single coherent answer by one author.

HARD RULES (all must be followed):

1. Format exactly as: ${r.output_format}

2. Address the user directly. Do NOT narrate the synthesis. No "After analyzing\u2026", "Combining the drafts\u2026", "Here's the synthesis\u2026".

3. Never refer to "the drafts", "the models", "Draft 1", "ChatGPT", "Claude", "Gemini", "Perplexity", or any AI by name. The user sees ONE answer from ONE author.

4. Where drafts disagreed, commit to the correct side. Do not hedge or present multiple options unless the user explicitly asked for options.

5. NO preamble. NO "Here's the answer:". NO "Great question!". NO meta-commentary at the start or end. Start directly with the answer.

6. Match the user's apparent expertise and tone. Casual user \u2192 casual answer. Technical user \u2192 precise answer.

7. Before sending, re-read the user's original task and verify your answer actually answers what they asked. If it drifts, fix it.${n}

Begin the final answer now:`}function g(e,t,r){return`YOU ARE A RED-TEAM REVIEWER. Not a friend. Not a coach. Not a polite editor.

Your job: FIND THE ERROR before it reaches the user. Another AI drafted the answer below. Errors in that draft will be shipped to the user unless you catch them now.

This is NOT a politeness exercise. Diplomatic critique that misses real errors is failure. Be specific. Be blunt. Quote the exact line that's wrong and say why.

The user's original task:

"""
${e}
"""

Task classification: ${r.task_type} (${r.difficulty} difficulty)
Required output format: ${r.output_format}

The draft to audit:

"""
${t.trim()}
"""

---

AUDIT THE DRAFT FROM SCRATCH. Do not assume any part of it is correct. Specifically attack:

  1. FACTUAL ERRORS \u2014 Any claim, name, date, number, definition, formula, or attribution that might be wrong. For each one you flag, briefly say WHY you doubt it.

  2. LOGICAL GAPS \u2014 Steps that are skipped, weakly justified, or that don't follow. Walk through the reasoning. Where does it break?

  3. MATHEMATICAL / CODE ERRORS \u2014 For math: recompute the key steps yourself. For code: trace the logic on a small input mentally. For both: check edge cases the draft skipped.

  4. MISSING CONTENT \u2014 What does the user clearly need that the draft did not address? Read the original task again. What did the draft skip?

  5. CALIBRATION \u2014 Is the draft over-confident on shaky ground? Under-confident on solid ground? Hedging unnecessarily? Inventing certainty?

  6. FORMAT MISMATCH \u2014 Required format was: "${r.output_format}". Does the draft match? If not, where does it deviate?

  7. WHAT IS RIGHT \u2014 List 1\u20133 things the draft genuinely got right. The reviser needs to know what NOT to touch. This is the only "polite" part of your output.

OUTPUT RULES:

- Output the audit as a structured list, one section per category above. Skip categories where you found nothing.
- For each issue: QUOTE the exact line or claim, then say what's wrong. Vague critiques ("could be clearer", "might be improved") are worse than useless.
- If the draft is genuinely solid and you find no real issues, say so in one line. Do NOT invent problems to look thorough \u2014 fake problems waste the reviser's time.
- Do NOT rewrite the answer. Do NOT produce a corrected version. Your job is the audit only.

Errors you miss become errors the user sees. Find them.`}function y(e,t,r,o){return`You wrote a draft. An independent reviewer audited it. Now you revise.

The audit may be excellent or may be partially wrong. Your job is to USE IT \u2014 accept real issues, reject over-fires, ship the best final answer.

The user's original task:

"""
${e}
"""

Required output format: ${o.output_format}

Your draft:

"""
${t.trim()}
"""

The reviewer's audit:

"""
${r.trim()}
"""

---

YOUR JOB:

1. Read the audit carefully. For each point the reviewer raised, decide whether it is:
     VALID         \u2014 real issue, must fix.
     PARTIALLY VALID \u2014 kernel of truth, address but not exactly as suggested.
     INVALID       \u2014 reviewer is wrong on this point, ignore.

2. The reviewer did NOT see the upstream proposer drafts you used. They may flag things as "missing" that you deliberately excluded for good reason. Trust your judgment \u2014 but do not be defensive. Real errors must be fixed regardless of who pointed them out.

3. If the audit said "this is solid, no real issues," your revision should be minor or zero. Don't change things just to look like you revised.

4. Produce the FINAL revised answer. This is what the user sees.

HARD RULES (all must be followed):

1. Format the answer exactly as: ${o.output_format}

2. Address the user directly. No "After reviewing the feedback\u2026", "Based on the critique\u2026", "I've revised\u2026", or ANY meta-commentary about the revision process.

3. Never refer to "the reviewer", "the critic", "the draft", "the audit", "the models", or any AI by name. The user sees one clean final answer.

4. NO preamble. NO "Here's the revised version:". Start directly with the answer.

5. Match the user's apparent expertise and tone.

6. Before sending, re-read the user's original task and verify your answer actually answers what they asked.

Begin the final revised answer now:`}},{"./config":"kdNLa","@parcel/transformer-js/src/esmodule-helpers.js":"f6DG4"}]},["kgW6q"],"kgW6q","parcelRequire3fb3"),globalThis.define=t;